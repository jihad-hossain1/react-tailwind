import React from 'react';
import Features from './Features';

const SingleCard = (props) => {
    // console.log(props.price);
    const {annual, features, monthly, type} = props.price;
    return (
        <div className='p-2 bg-purple-200 rounded'>
            <h2 className='text-center'> 
            <span className='text-3xl font-extrabold'>{monthly}</span>
            <span>/mon</span>
            </h2>
            <h2 className='text-purple-700 font-semibold text-center'>{type}</h2>
            <p> {
                features.map(feature => <Features feature={feature}></Features>)
                } </p>
            <div>
                <button className=''>Book Now</button>
            </div>
        </div>
    );
};

export default SingleCard;