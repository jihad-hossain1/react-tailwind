import React from 'react';

const Features = (props) => {
    console.log(props.feature);
    return (
        <div>
            {props.feature}
        </div>
    );
};

export default Features;